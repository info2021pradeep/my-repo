package com.e2is.restproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.e2is.restproject.model.Archive;

public interface ArchiveRepository extends JpaRepository<Archive, Long> {
	
	
}
