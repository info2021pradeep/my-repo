package com.e2is.restproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.e2is.restproject.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	Employee findById(int id);

}
