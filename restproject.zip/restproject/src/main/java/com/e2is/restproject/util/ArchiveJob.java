package com.e2is.restproject.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.e2is.restproject.model.Archive;
import com.e2is.restproject.model.Employee;
import com.e2is.restproject.repository.ArchiveRepository;
import com.e2is.restproject.repository.EmployeeRepository;

@Component
public class ArchiveJob {

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	ArchiveRepository archiveRepository;

	 @Scheduled(fixedDelay = 50000, initialDelay = 100000)
	public void archiveEmployeeData() {

		List<Employee> list = employeeRepository.findAll();
		for (Employee employee : list) {
			Archive archive = new Archive();
			archive.setEmployee_id(employee.getId());
			archive.setFirstName(employee.getFirstName());
			archive.setLastName(employee.getLastName());
			archive.setEmailId(employee.getEmailId());
			archive.setDept_id(employee.getDepartment().getId());
			archiveRepository.save(archive);

		}

	}

}
